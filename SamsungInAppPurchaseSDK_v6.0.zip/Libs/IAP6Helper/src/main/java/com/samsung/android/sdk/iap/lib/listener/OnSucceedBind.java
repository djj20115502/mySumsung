package com.samsung.android.sdk.iap.lib.listener;

/**
 * Created by sangbum7.kim on 2018-02-28.
 */

public interface OnSucceedBind {
}
